/*
Execution instructions:
gcc -o semaphore semaphore.c -lpthread
./semaphore
This file assumes that you are opening a default "message.txt"
*/

#include <assert.h>
#include <pthread.h>
#include <stdio.h>
#include <semaphore.h>
#include <stdlib.h>
#include <sys/wait.h>
#include <signal.h>
#include <unistd.h>
#include <stdbool.h>

#define NONSHARED 1
#define BUFFER 5 
   
sem_t empty, full;
        
bool eofHit = false;//boolean to track if EOF hit

char circular_arr[5];//array to hold 5 char's then circle back to first once arr full
int letterCounter = 0;//counter for letter's read in producer
int consumerRead = 0;//coutner for letter's read in consumer

pthread_t producer_tid;  
pthread_t consumer_tid;  

void * Consumer( void * arg ) 
{
  printf( "CustomerProducer created\n" );

  while( eofHit != true )//same outer while loop as producer, if EOF hit, then we're done
  {
 
    sem_wait( &empty );//makes consumer wait until producer reads char's

    while(consumerRead != letterCounter)//read as many char's as the producer was able, up to 5
    {
      printf("%c", circular_arr[consumerRead]);
      consumerRead++;
      sem_post( &full );//reset full to Buffer size
    }
    consumerRead = 0;//reset
 
    sem_post( &full );//give control back to producer

  }
  
  pthread_cancel(pthread_self());//after EOF hit, these used to return back to main
  pthread_cancel(producer_tid);
}


void * Producer( void * arg ) 
{

  printf( "Producer created\n" );
  FILE *fp;
  int temp;

  char letter;
  bool bufferHit = false;//used to check if reason while loop ended was 5 characters being read
  if((fp = fopen("message.txt", "r")) == NULL)
  {
    printf("ERROR: can't open message.txt\n");
    return 0;
  }

  while(eofHit != true)//until EOF hit,  continue to start from here
  {

    if(letterCounter != 0)//then not first iteration, used as I was losing 6th character read
    {
      letterCounter = 0;//reset
      circular_arr[letterCounter] = letter;
      letterCounter++;
    }

    bufferHit = false;//reset

    while(letterCounter != 5)
    {

      while(((letter = fgetc(fp)) != EOF) && bufferHit != true)//if the next char read is still valid
      {
        

        circular_arr[letterCounter] = letter;
        letterCounter++;
        if(letterCounter == 5)
          bufferHit = true;
      }
      

      if(bufferHit == true)//only calling sem_wait letterCounter times
      {

        for(int i = 0; i < letterCounter; i++)
        {
          sem_wait( &full );//full means buffer of 5 hit, increment 5 times to make full 0, jump to Consumer
        }

      }
      else//EOF hit, call sem_wait letterCounter times, and set EOF bool
      {

        for(int i = 0; i < letterCounter; i++)//iterate up to whatever letterCounter was before EOF reached
        {
          sem_wait( &full );
        }
 
        eofHit = true; //jump out of loop, no longer have char's to read
      }

    sem_post( &empty );//increment empty by 1, jump to consumer
    sem_wait( &full );//relinquish control to consumer
    }
    
  }
  
pthread_cancel(pthread_self());
}

int main( int argc, char *argv[] ) 
{
  time_t t;

  srand( ( unsigned int ) time( & t ) );

  //pthread_t producer_tid;  
  //pthread_t consumer_tid;  
  printf("\nMain started\n");
  sem_init( &empty, NONSHARED, 0);//0 for empty
  sem_init( &full, NONSHARED, BUFFER);//5 for buffer size

  //thread for consumer, create first, get stopped
  pthread_create( & consumer_tid, NULL, Consumer, NULL );
  //thread for producer, create after
  pthread_create( & producer_tid, NULL, Producer, NULL );

  pthread_join( producer_tid, NULL );
  pthread_join( consumer_tid, NULL );
  
  
  return 0;

}
