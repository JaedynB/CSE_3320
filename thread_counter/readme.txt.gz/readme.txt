Execution Instructions Part 1:
gcc -o substringTh# substringTh#.c -lpthread
./substringTh# filename.txt

**filename being whichever .txt file you want to run. personally tested with hamlet.txt and shakespeare.txt

** # being whichever file name you were wanting to run

Execution Instructions Part 2:
gcc -o semaphore semaphore.c -lpthread
./semaphore
This file assumes that you are opening a default "message.txt"
** I have included my own message.txt for your convenience

**I have also included the hamlet and shakespeare.txt files for your convenience
